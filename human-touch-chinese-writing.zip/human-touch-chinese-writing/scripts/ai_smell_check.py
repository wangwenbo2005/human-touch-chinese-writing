#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""AI 味体检：对一篇中文文稿做形式层与词汇层的确定性扫描。

用法：
    python ai_smell_check.py 文稿.md
    python ai_smell_check.py 文稿.md --top 20
    python ai_smell_check.py 文稿.md --json
    cat 文稿.md | python ai_smell_check.py -

脚本只负责把可疑之处标出来，不判断对错。命中的每一处都要人工确认：
这个表达在这里是否真的指向了具体的事。
"""

import argparse
import json
import re
import statistics
import sys

# ---------------------------------------------------------------- 词表

LEXICON = {
    "宏大叙事": ["时代浪潮", "时代注脚", "历史坐标", "崭新篇章", "壮阔图景", "精神底色",
                 "时代命题", "深刻变革", "历史性跨越", "时代回响", "宏伟蓝图", "历史方位"],
    "深刻哲理": ["底层逻辑", "深层逻辑", "本质上说", "归根结底", "重新审视", "价值重构",
                 "精神内核", "深刻启示", "内在张力", "核心密码", "深层原因", "逻辑起点"],
    "宣传公文": ["赋能", "蓄势待发", "行稳致远", "提质增效", "协同发力", "久久为功",
                 "凝心聚力", "守正创新", "深耕细作", "高质量发展", "聚力攻坚", "系统施策"],
    "学术商业": ["生态闭环", "多维赋能", "路径探索", "创新范式", "体系构建", "多元协同",
                 "系统性重塑", "场景落地", "价值跃迁", "范式转型", "方法论", "闭环"],
    "情绪修辞": ["令人动容", "不禁感慨", "意味深长", "发人深省", "不容忽视", "值得深思",
                 "震撼人心", "引人深思", "悄然发生", "掷地有声", "久久不能平静", "为之动容"],
    "逻辑连接": ["值得注意的是", "不可否认的是", "毋庸置疑", "不难发现", "事实上", "与此同时",
                 "换言之", "由此可见", "更重要的是", "在某种意义上", "众所周知", "显而易见"],
}

# 单独拎出来加倍提醒的词
PRIORITY_WORDS = ["赋能", "底色", "图景", "注脚", "浪潮", "深耕", "重塑", "范式",
                  "张力", "内核", "破局", "跃迁", "深刻变革", "崭新篇章", "底层逻辑"]

# ---------------------------------------------------------------- 句式

PATTERNS = [
    ("不是A而是B", r"不是[^。！？\n]{1,25}[，,]?\s*而是", "强行制造对立。真的存在这个对立吗"),
    ("并非A而是B", r"并非[^。！？\n]{1,25}[，,]?\s*而是", "同上，换个字不解决问题"),
    ("不仅A更B", r"不仅[^。！？\n]{0,30}[，,]?\s*更(?!加|新|为|是)", "习惯性拔高，B 往往是硬凑的高度"),
    ("从A到B从C到D", r"从[^，,。\n]{1,15}到[^，,。\n]{1,15}[，,]\s*从", "机械排比，四组词轮流上场"),
    ("既要A也要B", r"既要[^。！？\n]{0,30}[，,]?\s*(也要|又要|还要)", "安全而空泛，等于没表态"),
    ("A的背后是B", r"背后[，,]?\s*(是|其实|正|往往|隐藏)", "伪装成揭示本质"),
    ("如果说A那么B", r"如果说[^。！？\n]{0,30}[，,]\s*那么", "刻意修辞，为对称牺牲准确"),
    ("当我们谈论A", r"当我们(谈论|讨论|说起|提到)", "模板化设问"),
    ("或许这就是", r"或许[，,]?\s*这就是", "感叹式结尾"),
    ("如何A如何B", r"如何[^？?\n]{1,20}[？?][^\n]{0,15}如何", "连问不答，冒充紧迫感"),
    ("让A真正成为B", r"让[^。！？\n]{1,15}真正(成为|落地|发生|运转)", "抽象概念互相解释"),
    ("首先其次最后", r"首先[^。\n]{0,80}其次", "万能三分法的典型骨架"),
    ("抽象名词+冒号", r"^\s*(?:[一二三四五六七八九十]+[、.]|\d+[.、])?\s*[\u4e00-\u9fa5]{2,6}[：:]\s*[\u4e00-\u9fa5]{2,8}[，,]", "冒号前后是否都是抽象概念"),
]

# ---------------------------------------------------------------- 阈值
TH = {
    "quote_per_k": 6.0,      # 引号（对数）/千字
    "colon_per_k": 5.0,      # 冒号/千字
    "dash_per_k": 2.5,       # 破折号/千字
    "semi_per_k": 5.0,       # 分号/千字
    "quest_per_k": 4.0,      # 问号/千字
    "single_sent_ratio": 0.35,   # 单句成段占比
    "para_mean_min": 60,     # 平均段长下限
    "para_cv_max": 0.38,     # 段长变异系数下限（低于此过于均匀）
    "heading_per_k": 1.2,    # 小标题/千字
    "bold_per_k": 3.0,       # 加粗/千字
    "word_kinds_warn": 5,    # 命中的不同高频词种类
}

CJK = re.compile(r"[\u4e00-\u9fa5]")
SENT_END = re.compile(r"[。！？!?]")
HEADING = re.compile(r"^\s*(#{1,6}\s|[一二三四五六七八九十]+[、.]|\d+[.、]\s*[^\d])")
LIST_ITEM = re.compile(r"^\s*([-*+]\s+|\d+[.)]\s+)")
BOLD = re.compile(r"\*\*[^*\n]+\*\*")
HR = re.compile(r"^\s*(-{3,}|\*{3,}|_{3,})\s*$")


def load(path):
    if path == "-":
        return sys.stdin.read()
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        return f.read()


def split_lines(text):
    """返回 [(行号, 类型, 原始行, 正文)]，类型为 heading/para/list/hr/blank。"""
    out = []
    for i, line in enumerate(text.split("\n"), 1):
        s = line.strip()
        if not s:
            out.append((i, "blank", line, ""))
        elif HR.match(s):
            out.append((i, "hr", line, s))
        elif HEADING.match(s):
            body = re.sub(r"^#{1,6}\s*", "", s)
            body = re.sub(r"^[一二三四五六七八九十]+[、.]\s*", "", body)
            body = re.sub(r"^\d+[.、]\s*", "", body)
            out.append((i, "heading", line, body))
        elif LIST_ITEM.match(s):
            body = re.sub(r"^\s*([-*+]\s+|\d+[.)]\s+)", "", s)
            out.append((i, "list", line, body))
        else:
            out.append((i, "para", line, s))
    return out


def count_sentences(p):
    n = len(SENT_END.findall(p))
    return max(n, 1)


def snippet(p, n=26):
    p = p.strip()
    return p[:n] + ("…" if len(p) > n else "")


def analyze(text):
    lines = split_lines(text)

    # 正文 = 段落 + 列表；标题单独统计
    body_paras = [(ln, body) for (ln, t, _, body) in lines if t in ("para", "list") and body]
    headings = [(ln, body) for (ln, t, _, body) in lines if t == "heading"]
    hr_count = sum(1 for (_, t, _, _) in lines if t == "hr")

    plain = "\n".join(b for (_, b) in body_paras) + "\n" + "\n".join(b for (_, b) in headings)
    chars = len(CJK.findall(plain)) + len(re.findall(r"[A-Za-z0-9]", plain))
    chars = max(chars, 1)
    k = chars / 1000.0

    report = {"chars": chars, "paragraphs": len(body_paras), "headings": len(headings),
              "dimensions": [], "warnings": 0}

    def add(name, level, title, detail, items=None):
        report["dimensions"].append({"name": name, "level": level, "title": title,
                                     "detail": detail, "items": items or []})
        if level == "warn":
            report["warnings"] += 1

    # ---------------- 词汇
    hits = []
    kinds = set()
    for cat, words in LEXICON.items():
        for w in words:
            for (ln, body) in body_paras + headings:
                for m in re.finditer(re.escape(w), body):
                    hits.append({"word": w, "cat": cat, "line": ln,
                                 "ctx": snippet(body[max(0, m.start() - 8):m.start() + 14]),
                                 "priority": w in PRIORITY_WORDS})
                    kinds.add(w)
    if len(kinds) >= TH["word_kinds_warn"]:
        lvl = "warn"
    elif kinds:
        lvl = "note"
    else:
        lvl = "ok"
    detail = "命中 %d 处 / %d 种" % (len(hits), len(kinds))
    if hits:
        detail += "；其中重点词 %d 处" % sum(1 for h in hits if h["priority"])
    add("词汇", lvl, "高频抽象词", detail, hits)

    # ---------------- 句式
    phits = []
    for name, rx, why in PATTERNS:
        for (ln, body) in body_paras + headings:
            for m in re.finditer(rx, body):
                phits.append({"name": name, "why": why, "line": ln,
                              "ctx": snippet(body[max(0, m.start() - 6):m.end() + 6])})
    if len(phits) >= 4:
        lvl = "warn"
    elif phits:
        lvl = "note"
    else:
        lvl = "ok"
    add("句式", lvl, "模板句式", "命中 %d 处" % len(phits), phits)

    # ---------------- 标点
    pdef = [
        ("引号", r'[“”"]', "quote_per_k", 0.5, 2,
         "引号只用于直接引用、特定称谓、必要强调；给普通名词加引号是典型痕迹"),
        ("冒号", r"[：:]", "colon_per_k", 1.0, 1,
         "警惕“抽象名词＋冒号＋抽象解释”，冒号后面要有事实"),
        ("破折号", r"——|—", "dash_per_k", 1.0, 1,
         "破折号不要用来制造戏剧性停顿"),
        ("分号", r"[；;]", "semi_per_k", 1.0, 1,
         "分号排比容易把评论写成工作报告"),
        ("问号", r"[？?]", "quest_per_k", 1.0, 1,
         "连续设问不回答是冒充紧迫感；每个问句后面要有回应"),
    ]
    pstats = []
    pbad = 0
    for label, rx, key, scale, div, note in pdef:
        n = len(re.findall(rx, plain))
        unit = n / div if div > 1 else n
        ratio = unit / k * scale
        over = ratio > TH[key]
        if over:
            pbad += 1
        pstats.append({"label": label, "count": round(unit, 1), "per_k": round(ratio, 2),
                       "threshold": TH[key], "over": over, "note": note})
    add("标点", "warn" if pbad >= 2 else ("note" if pbad else "ok"),
        "标点密度", "每千字：%s" % "，".join("%s %.1f" % (s["label"], s["per_k"]) for s in pstats), pstats)

    # ---------------- 段落
    lens = [len(CJK.findall(p)) for (_, p) in body_paras] or [0]
    sents = [count_sentences(p) for (_, p) in body_paras] or [0]
    mean = statistics.mean(lens) if lens else 0
    sd = statistics.pstdev(lens) if len(lens) > 1 else 0
    cv = (sd / mean) if mean else 0
    single = sum(1 for s in sents if s <= 1)
    single_ratio = single / max(len(lens), 1)
    short = sum(1 for L in lens if L < 40)

    plevel = "ok"
    pd = []
    n_para = len(lens)
    if single_ratio > TH["single_sent_ratio"] and n_para >= 4:
        plevel = "warn"
        pd.append("单句成段占 %.0f%%（%d/%d），一句一换行是聊天产品的排版习惯"
                  % (single_ratio * 100, single, n_para))
    if mean < TH["para_mean_min"] and n_para >= 4:
        plevel = "warn"
        pd.append("平均段长仅 %.0f 字，文章被切得过碎" % mean)
    if cv < TH["para_cv_max"] and n_para >= 8:
        plevel = plevel if plevel == "warn" else "note"
        pd.append("段长变异系数 %.2f，段落长度过于均匀，节奏机械" % cv)
    if not pd:
        pd.append("平均段长 %.0f 字，段长变异 %.2f，单句成段 %.0f%%，分布正常"
                  % (mean, cv, single_ratio * 100))

    add("段落", plevel, "段落节奏",
        "共 %d 段，最长 %d 字，最短 %d 字；" % (len(lens), max(lens), min(lens)) + "；".join(pd),
        [{"line": ln, "len": len(CJK.findall(p)), "ctx": snippet(p, 20)}
         for (ln, p), L in zip(body_paras, lens) if L < 25][:12])

    # ---------------- 结构
    hper = len(headings) / k
    bolds = len(BOLD.findall(plain))
    bper = bolds / k
    struct_warn = []
    if hper > TH["heading_per_k"] and chars > 800:
        struct_warn.append("小标题密度 %.1f/千字，%d 个标题，文章被拆成 PPT 提纲" % (hper, len(headings)))
    if bper > TH["bold_per_k"]:
        struct_warn.append("加粗 %d 处（%.1f/千字），重点应该由论证顶出来，不靠加粗提示" % (bolds, bper))
    if hr_count >= 3:
        struct_warn.append("分隔线 %d 条，正式文章一般不需要" % hr_count)
    add("结构", "warn" if len(struct_warn) >= 2 else ("note" if struct_warn else "ok"),
        "版式痕迹", "；".join(struct_warn) if struct_warn else
        "小标题 %.1f/千字、加粗 %d 处，未过度分层" % (hper, bolds),
        [{"line": ln, "ctx": snippet(b, 24)} for (ln, b) in headings][:12])

    # ---------------- 结论
    w = report["warnings"]
    if w >= 4:
        verdict = "AI 味偏重：四个维度都有明显痕迹，建议按 references/rewrite-examples.md 整篇重写，而不是逐句润色。"
    elif w >= 2:
        verdict = "有明显痕迹：命中项需要逐条处理，尤其是抽象词密集的段落。"
    elif w >= 1:
        verdict = "轻度痕迹：形式基本自然，重点检查命中位置是否真的在说具体的事。"
    else:
        verdict = "形式层干净。仍需人工确认：读完之后，读者是否获得了新的信息或判断。"
    report["verdict"] = verdict
    return report


def print_report(rep, top):
    W = "=" * 62
    print(W)
    print("中文人味体检    字数 %d    段落 %d    小标题 %d" % (rep["chars"], rep["paragraphs"], rep["headings"]))
    print(W)

    marks = {"warn": "[!]", "note": "[·]", "ok": "[✓]"}
    for d in rep["dimensions"]:
        print("\n%s %s｜%s" % (marks[d["level"]], d["title"], d["detail"]))
        items = d["items"][:top]
        if d["name"] == "词汇":
            for h in items:
                print("      第%-4s 行  %s%s  ← %s" % (h["line"], h["word"],
                                                       "" if not h["priority"] else " ★", h["ctx"]))
        elif d["name"] == "句式":
            for h in items:
                print("      第%-4s 行  %-10s  %s" % (h["line"], h["name"], h["ctx"]))
                print("                 → %s" % h["why"])
        elif d["name"] == "标点":
            for s in items:
                flag = "  ↑超标" if s["over"] else ""
                print("      %-4s %5.1f 处  %.1f/千字%s" % (s["label"], s["count"], s["per_k"], flag))
                if s["over"]:
                    print("           → %s" % s["note"])
        elif d["name"] == "段落":
            if items:
                print("      过短段落：")
                for h in items:
                    print("      第%-4s 行  %2d 字  %s" % (h["line"], h["len"], h["ctx"]))
        elif d["name"] == "结构":
            if items:
                print("      标题：")
                for h in items:
                    print("      第%-4s 行  %s" % (h["line"], h["ctx"]))
        if len(d["items"]) > top:
            print("      ……另有 %d 条，用 --top N 展开" % (len(d["items"]) - top))

    print("\n" + W)
    print("结论：%s" % rep["verdict"])
    print("提示：这只是机器能看见的部分。词汇和标点都可以合规，文章仍然可能空转——")
    print("     真正的判断标准是：读完有没有获得新的事实、新的机制、或者一个真判断。")
    print(W)


def main():
    ap = argparse.ArgumentParser(description="中文文稿 AI 味体检")
    ap.add_argument("path", help="文稿路径，-表示从标准输入读取")
    ap.add_argument("--top", type=int, default=8, help="每类最多列出的条数，默认 8")
    ap.add_argument("--json", action="store_true", help="输出 JSON")
    args = ap.parse_args()

    try:
        text = load(args.path)
    except OSError as e:
        print("读取失败：%s" % e, file=sys.stderr)
        return 2

    if not text.strip():
        print("文稿为空", file=sys.stderr)
        return 2

    rep = analyze(text)
    if args.json:
        print(json.dumps(rep, ensure_ascii=False, indent=2))
    else:
        print_report(rep, args.top)
    return 0


if __name__ == "__main__":
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
    sys.exit(main())
